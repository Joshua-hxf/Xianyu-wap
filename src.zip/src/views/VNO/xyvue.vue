<template>
  <div>
    <div v-for="item in noteList" :key="item.id">
      <card>
        <div class="note-title">{{ item.title }}</div>
        <!-- <div class="note-time">{{ item.time.split(' ')[0] }}</div>
        <div class="note-text" v-html="ellipsis(item.text)" v-highlight></div> -->
      </card>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { getNoteList } from '@/api/store'
import Card from '@/common/card'

export default {
  name: 'xyvue',
  components: {
    Card
  },
  data () {
    return {
      noteList: [],
      localpage: 'Vue'
    }
  },
  methods: {
    ellipsis (value) {
      if (value.length > 325) {
        return value.slice(0, 325) + '<span>...</span>'
      }
      return value
    },
    _getNoteList () {
      getNoteList(this.localpage).then((res) => {
        this.noteList = res.data.noteList
      })
    }
  },
  created () {
    this._getNoteList()
  },
  mounted () {
    this.localpage = this.$route.name
  },
  watch: {
    $route (to) {
      this.localpage = to.name
    }
  }
}

</script>

<style lang="stylus" rel="stylesheet/stylus" scoped>

</style>
